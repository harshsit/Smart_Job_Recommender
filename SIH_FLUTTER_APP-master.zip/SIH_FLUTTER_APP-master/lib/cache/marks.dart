
getmarks(List<dynamic> a)
{
 return a;
}