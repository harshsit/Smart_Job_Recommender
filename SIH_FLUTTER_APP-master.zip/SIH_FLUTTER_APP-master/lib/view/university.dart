// import 'package:flutter/material.dart';
// import 'package:flutter_app/view/checkbox.dart';

// class University extends StatefulWidget {
//   University({Key key}) : super(key: key);

//   @override
//   _University createState() => _University();
// }

// class _University extends State<University> {
//   bool Is_University = false;

//   @override
//   Widget build(BuildContext context) {
//     return LabeledCheckbox(
//       label: 'University',
//       padding: const EdgeInsets.symmetric(horizontal: 20.0),
//       value: Is_University,
//       onChanged: (bool newValue) {
//         setState(() {
//           Is_University = newValue;
//         });
//       },
//     );
//   }
// }
