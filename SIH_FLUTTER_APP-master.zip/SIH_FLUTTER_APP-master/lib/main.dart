
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter_app/results/finalresult.dart';
import 'package:flutter_app/questions/general_question.dart';
import 'package:flutter_app/view/login.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/view/experiment_homepage.dart';
import 'package:flutter_app/view/splash.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'package:flutter_app/view/dashboard.dart';
import 'package:flutter_app/view/profile.dart';

import 'package:flutter_app/view/splash.dart';

import 'view/profile.dart';
import 'view/profile.dart';
import 'view/profile.dart';


void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) { 
    return MaterialApp(

      title: "YourPerfectJob",

      debugShowCheckedModeBanner: false,
      home: SplashScreen(),//MainPage(),
      theme: ThemeData(
          primaryColor: Colors.deepPurple,
      ),
    );
  }
}

class MainPage extends StatefulWidget {
    MainPage({Key key, this.usertok,this.dom,this.subdom,this.rate}) : super(key: key);
   final String usertok;
   final String dom;
   final String subdom;
   final String rate;
  
  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  
  int _page = 0;
  GlobalKey _bottomNavigationKey = GlobalKey();


  SharedPreferences sharedPreferences;

  @override
  void initState() {
    //super.initState();
    checkLoginStatus();
    super.initState();
  }

  checkLoginStatus() async {
    sharedPreferences = await SharedPreferences.getInstance();
    if(sharedPreferences.getString("token") == null) {
      Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (BuildContext context) => LoginPage()), (Route<dynamic> route) => false);
    }
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: CurvedNavigationBar(
        key: _bottomNavigationKey,
        index: 0,
        height: 50.0,
        items: <Widget>[
          Icon(Icons.home, size: 30,),
          Icon(Icons.assignment, size: 30),
          Icon(Icons.person, size: 30),

        ],

        color: Colors.white,
        buttonBackgroundColor: Colors.white,
        backgroundColor: Colors.deepPurple,
        animationCurve: Curves.easeInOut,
        animationDuration: Duration(milliseconds: 600),

        onTap: (index) {
          setState(() {
            _page = index;
          });
          switch(_page){
            case 0:
              {
                print("1st");
              }
              break;
            case 1:
              {
               print("2nd");
               //Navigator.of(context).push(MaterialPageRoute(builder: (BuildContext context) => Splash1Screen()));
              }
              break;
            case 2:
              {
                Navigator.of(context).push(MaterialPageRoute(builder: (BuildContext context) => ProfilePage()));
              }
              break;


          }
        },
      ),
      appBar: AppBar(
        title: Text("YourPerfectJob", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.deepPurple,
        actions: <Widget>[
          FlatButton(
            onPressed: () {
              sharedPreferences.clear();

              Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (BuildContext context) => LoginPage()), (Route<dynamic> route) => false);
            },
            child: Text("Log Out", style: TextStyle(color: Colors.white)),

          ),
        ],
      ),
      body:
      Center(child: Main1Page(usertoken:"${widget.usertok}",domainchosen: widget.subdom,),),

      drawer: Drawer(
        child: new ListView(
          children: <Widget>[
            new UserAccountsDrawerHeader(
              accountName: new Text('Manish'),
              accountEmail: new Text('1234@gmail.com'),
              
              
              // decoration: new BoxDecoration(
              //   image: new DecorationImage(
              //     fit: BoxFit.fill,
              //    image: AssetImage("assets/profile10.png"),
              //   )
              // ),
            ),
            new Divider(),
            new ListTile(
              title: new Text("Profile(IN PROGRESS Token ${widget.usertok})"),
              trailing: new Icon(Icons.person),
              onTap: () => Navigator.of(context).push(new MaterialPageRoute(
                builder: (BuildContext context) => ProfilePage(subdomain: widget.subdom,tok: "${widget.usertok}",),
              )),
            ),
            new Divider(),
            new ListTile(
              title: new Text("Job Recommendation Quiz Token:${widget.usertok}   \n Quiz under Construction till next beta release" ),
              trailing: new Icon(Icons.question_answer),
              onTap: () => Navigator.of(context).push(new MaterialPageRoute(
                builder: (BuildContext context) => HomePage(usertokvar: "${widget.usertok}",),
              )),
            ),
            new Divider(),
            new ListTile(
              title: new Text("FAQ \n Under Progress"),
              trailing: new Icon(Icons.reorder),
              // onTap: () => Navigator.of(context).push(new MaterialPageRoute(
              //   builder: (BuildContext context) => ItemReviewsPage(),
              // )),
            ),
             new Divider(),
            new ListTile(
              title: new Text("Feedback(IN PROGRESS)"),
              trailing: new Icon(Icons.rate_review),
              // onTap: () => Navigator.of(context).push(new MaterialPageRoute(
              //   builder: (BuildContext context) => ItemReviewsPage(),
              // )),
            ),
            

          ],
        ),
      ),
    );
  }
}